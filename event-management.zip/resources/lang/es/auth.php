<?php

return [
    'failed'   => 'Estas credenciales no coinciden con nuestros registros.',
    'password' => 'La contraseña que ha ingresado es incorrecta.',
    'throttle' => 'Muchos intentos para ingresar. Por favor intente de nuevo en :seconds segundos',

];
