<?php

return [
    'failed'   => 'Essas credenciais não correspondem aos nossos registros.',
    'password' => 'A senha está incorreta',
    'throttle' => 'Muitas tentativas de login. Tente novamente em :seconds segundos.',

];
