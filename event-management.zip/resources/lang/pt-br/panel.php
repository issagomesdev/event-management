<?php

return [
    'site_title' => 'Listinha VIP',

];
