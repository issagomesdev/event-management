<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.events.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.event.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.event.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Event">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.name')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.start')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.end')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.visualization')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.type')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.event.fields.allow_guests')); ?>

                        </th>
                    </tr>
                    <tr>
                        <td>
                        </td>
                        <td>
                            <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                        </td>
                        <td>
                            <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                        </td>
                        <td>
                            <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                        </td>
                        <td>
                            <input class="search" type="text" placeholder="<?php echo e(trans('global.search')); ?>">
                        </td>
                        <td>
                            <select class="search" strict="true">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = App\Models\Event::VISUALIZATION_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <select class="search" strict="true">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = App\Models\Event::TYPE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <select class="search" strict="true">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = App\Models\Event::ALLOW_GUESTS_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td> </td>
                            <td>
                                <?php echo e($event->id ?? ''); ?>

                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.events.show', $event->id)); ?>">
                                <?php echo e($event->name ?? ''); ?>

                                </a>
                            </td>
                            <td>
                                <?php echo e($event->start ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($event->end ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Event::VISUALIZATION_RADIO[$event->visualization] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Event::TYPE_RADIO[$event->type] ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Event::ALLOW_GUESTS_RADIO[$event->allow_guests] ?? ''); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-Event:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  console.log(table)
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
let visibleColumnsIndexes = null;
$('.datatable thead').on('input', '.search', function () {
      let strict = $(this).attr('strict') || false
      let value = strict && this.value ? "^" + this.value + "$" : this.value

      let index = $(this).parent().index()
      if (visibleColumnsIndexes !== null) {
        index = visibleColumnsIndexes[index]
      }

      table
        .column(index)
        .search(value, strict)
        .draw()
  });
table.on('column-visibility.dt', function(e, settings, column, state) {
      visibleColumnsIndexes = []
      table.columns(":visible").every(function(colIdx) {
          visibleColumnsIndexes.push(colIdx);
      });
  })
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/admin/events/index.blade.php ENDPATH**/ ?>