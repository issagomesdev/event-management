<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.event.title')); ?>

    </div>

    
    <table class="table table-bordered table-striped" id="full-data">
        <tbody>
            <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key+1); ?> - <?php echo e($item->name); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.events.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
                <div class="data-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_edit')): ?>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.events.edit', $event->id)); ?>">
                            <?php echo e(trans('global.edit')); ?>

                        </a>
                    <?php endif; ?>
    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('event_delete')): ?>
                        <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($event->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.photo')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $event->photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e($media->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($media->getUrl('thumb')); ?>">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.cover')); ?>

                        </th>
                        <td>
                            <?php if($event->cover): ?>
                                <a href="<?php echo e($event->cover->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($event->cover->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($event->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.start')); ?>

                        </th>
                        <td>
                            <?php echo e($event->start); ?> <?php echo e($event->start_time); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.end')); ?>

                        </th>
                        <td>
                            <?php echo e($event->end); ?> <?php echo e($event->end_time); ?>

                        </td>
                    </tr><tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.country')); ?>

                        </th>
                        <td>
                            <?php echo e($event->country); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.state')); ?>

                        </th>
                        <td>
                            <?php echo e($event->state); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.city')); ?>

                        </th>
                        <td>
                            <?php echo e($event->city); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.neighborhood')); ?>

                        </th>
                        <td>
                            <?php echo e($event->neighborhood); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.street')); ?>

                        </th>
                        <td>
                            <?php echo e($event->street); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.number')); ?>

                        </th>
                        <td>
                            <?php echo e($event->number); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo $event->description; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.rules')); ?>

                        </th>
                        <td>
                            <?php echo $event->rules; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.link')); ?>

                        </th>
                        <td>
                            <?php echo e($event->link); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.link_instruction')); ?>

                        </th>
                        <td>
                            <?php echo e($event->link_instruction); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.pixel')); ?>

                        </th>
                        <td>
                            <?php echo e($event->pixel); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.whatsapp')); ?>

                        </th>
                        <td>
                            <?php echo e($event->whatsapp); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.whatsappmessage')); ?>

                        </th>
                        <td>
                            <?php echo e($event->whatsappmessage); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.visualization')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Event::VISUALIZATION_RADIO[$event->visualization] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.type')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Event::TYPE_RADIO[$event->type] ?? ''); ?>

                        </td>
                    </tr>
                    <?php if($event->type === '0'): ?>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.capacity')); ?>

                        </th>
                        <td>
                            <?php echo e($event->capacity); ?>

                        </td>
                    </tr>
                    <?php endif; ?>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.allow_guests')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Event::ALLOW_GUESTS_RADIO[$event->allow_guests] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            URL
                        </th>
                        <td>
                            <a href="/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>"><?php echo e(rtrim(url('/'), '/')); ?>/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?></a>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            URL da lista
                        </th>
                        <td>
                            <a href="/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>/list"><?php echo e(rtrim(url('/'), '/')); ?>/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>/list</a>
                        </td>
                    </tr>
                    <tr>

                        <th>
                            URL do checkin
                        </th>
                        <td>
                            <a href="/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>/checkin"><?php echo e(rtrim(url('/'), '/')); ?>/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>/checkin</a>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.created_at')); ?>

                        </th>
                        <td>
                            <?php echo e($event->created_at); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.event.fields.updated_at')); ?>

                        </th>
                        <td>
                            <?php echo e($event->updated_at); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="attendances">
                <div class="infos">
                    <h2>Lista de presença do evento</h2>
                    <div class="actions">
                        <div class="save" id="toPDF" onclick="exportToPDF()">
                            <iconify-icon icon="ic:round-file-download"></iconify-icon>
                            <span>Baixar PDF</span>
                        </div>
                        <div class="save" id="toCSV" onclick="exportToCSV()">
                            <iconify-icon icon="ph:file-csv-duotone"></iconify-icon>
                            <span>Exportar CSV</span>
                        </div>
                        <div class="save" id="groupBy_clients" onclick="groupList(this)">
                            <iconify-icon icon="heroicons:user-group-16-solid"></iconify-icon>
                            <span>Agrupar por nome</span>
                        </div>
                        <div class="save" id="orderBy_id" onclick="orderList(this)">
                            <iconify-icon icon="mdi:order-alphabetical-ascending"></iconify-icon>
                            <span>Ordenação Alfabetica</span>
                        </div>
                    </div>
                </div>
                <div class="list">
                    <?php $__currentLoopData = $attendanceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <h4>
                                <p><?php echo e($list->name); ?> <?php echo e($list->surname); ?> 
                                    <?php if(count($list->guests) > 0): ?>
                                    <iconify-icon class="show-guests" onclick="showGuests(this)" icon="bxs:right-arrow"></iconify-icon> 
                                    <?php endif; ?>
                                </p>
                            </h4>
                                <?php if(count($list->guests) > 0): ?>
                                <div class="guests">
                                    <?php $__currentLoopData = $list->guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="guest">
                                        <p><?php echo e($guest->guest); ?></p>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <h2><?php echo e($attendanceCheckInCount); ?> Compareceram de <?php echo e($attendanceCount); ?> Convidados</h2>
            </div>
        </div>
    </div>
</div>
<script src="/js/jspdf/jspdf.umd.js"></script>
<script src="/js/jspdf/jspdf.plugin.autotable.js"></script>

<script>

    let groupby = 'clients';
    let orderby = 'id';

    function showGuests(el) {
        
        console.log(el, el.closest(".item"))
        var showEl = el.closest(".item").querySelector(".guests");
        if(showEl.classList.contains('show')){
            showEl.classList.remove('show');
            el.icon="bxs:right-arrow";
        } else {
            showEl.classList.add('show')
            el.icon="bxs:down-arrow";
        }
    }

	function exportToPDF() {
		var doc = new jspdf.jsPDF()

        doc.text('Lista de presença - <?php echo e($event->name); ?>', 15, 15);
		doc.autoTable({ html: 'table#full-data', startY: 20 })

		doc.save('lista_<?php echo e($event->name); ?>.pdf')
	}

	function exportToCSV() {
		var table = document.querySelector('table#full-data');
		var csvData = [
            <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                Nome: "<?php echo e($item->name); ?>"
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        
        const header = Object.keys(csvData[0]).join(',') + '\n';
        const rows = csvData.map(obj => Object.values(obj).join(',')).join('\n');
    	const blob = new Blob([header + rows], { type: 'text/csv' });
		const link = document.createElement('a');
		link.href = URL.createObjectURL(blob);
		link.download = 'lista_<?php echo e($event->name); ?>.csv';
		document.body.appendChild(link);
    	link.click();
	}

    function groupList(el) {
        if(el.id === "groupBy_clients") {
            el.id = "groupBy_name";
            groupby = "name";
        } else {
            el.id = "groupBy_clients";
            groupby = "clients";
        }

        reloadList()
    }

    function orderList(el) {

        if(el.id === "orderBy_id") {
            el.id = "orderBy_abc";
            orderby = "abc";
        } else {
            el.id = "orderBy_id";
            orderby = "id";
            
        }
        
        reloadList()
    }

    function reloadList() {
        const listEl = document.querySelector('.list');

        let list = [];

        if(groupby === "clients") {
            list = [
                <?php $__currentLoopData = $attendanceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    id: <?php echo e($key+1); ?>,
                    name: "<?php echo e($list->name); ?> <?php echo e($list->surname); ?>",
                    guest: [
                    <?php $__currentLoopData = $list->guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           {
                            id: <?php echo e($key+1); ?>,
                            name: "<?php echo e($guest->guest); ?>",
                           }, 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        } else {
            list = [
                <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    id: <?php echo e($key+1); ?>,
                    name: "<?php echo e($list->name); ?>",
                    type: "<?php echo e($list->type); ?>"
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        }

        if(orderby === "id"){
            list.sort((a, b) => a.id - b.id);
        } else {
            list.sort((a, b) => a.name.localeCompare(b.name));
        }

        listEl.innerHTML = `${list.map(function(item) {
                        return `<div class="item">
                            <h4> <p>${item.name} 
                                ${item.guest && item.guest.length > 0? '<iconify-icon class="show-guests" onclick="showGuests(this)" icon="bxs:right-arrow"></iconify-icon>' : ''}
                                </p> 
                            </h4>
                            ${item.guest && item.guest.length > 0? `
                            <div class="guests">
                            ${item.guest.map(function(guest) {
                            return `<div class="guest">
                                    <p>${guest.name}</p>
                                </div>`
                            }).join('')}
                            </div>
                            ` : '' }
                            </div>`
                        }).join('')}`
        
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/admin/events/show.blade.php ENDPATH**/ ?>