<!DOCTYPE html>
<html>
<head>
    <title>Proteção por Senha</title>
</head>
<body>

    <?php if(session('error')): ?>
        <div style="color: red;">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    
    <form method="GET" action="<?php echo e(url()->current()); ?>" style="display: flex; justify-content: center; flex-direction: column; align-items: center;">

        <div class="field" style="margin-bottom: 1em">
            <label for="password">User:</label>
            <input type="text" name="user" id="user" required>
        </div>

        <div class="field" style="margin-bottom: 1em">
            <label for="password">Senha:</label>
            <input type="password" name="password" id="password" required>
        </div>
        <button type="submit">Prosseguir</button>
    </form>
</body>
</html>
<?php /**PATH C:\laragon\www\event-management\resources\views/public/events/password-protect.blade.php ENDPATH**/ ?>