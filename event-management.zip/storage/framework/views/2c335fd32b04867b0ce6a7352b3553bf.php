<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.customer.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.customers.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
                <div class="data-actions">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_edit')): ?>
                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.customers.edit', $customer->id)); ?>">
                            <?php echo e(trans('global.edit')); ?>

                        </a>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('customer_delete')): ?>
                        <form action="<?php echo e(route('admin.customers.destroy', $customer->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.surname')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->surname); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.phonenumber')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->phonenumber); ?>

                        </td>
                    </tr>
                    
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.customer.fields.birthdate')); ?>

                        </th>
                        <td>
                            <?php echo e($customer->birthdate); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#attendance_list_events" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.event.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="attendance_list_events">
            <?php if ($__env->exists('admin.customers.relationships.attendanceListEvents', ['events' => $customer->attendanceListEvents])) echo $__env->make('admin.customers.relationships.attendanceListEvents', ['events' => $customer->attendanceListEvents], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>