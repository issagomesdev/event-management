<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    Eventos
                </div>
            </div>
                
            <div class="events">
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="event">
                        <div class="title">
                            <h2><?php echo e($event->name); ?></h2>
                            <div class="menu">   
                                <iconify-icon onclick="showMenu(this)" icon="ic:round-menu"></iconify-icon>
                                <div class="actions hidden">
                                    <a href="<?php echo e(route('admin.events.show', $event->id)); ?>">Visualizar Evento</a>
                                    <a href="<?php echo e(route('admin.events.checkin', $event->id)); ?>">Acessar CheckIn</a>
                                </div>
                            </div>
                        </div>
                        <p> <?php echo e($event->start ?? 'em breve'); ?> <?php echo e($event->start_time); ?> - <?php echo e($event->end ?? 'em breve'); ?> <?php echo e($event->end_time); ?> </p>
                        <div class="attendeds">
                            <div class="attended" id="checkIn">
                                <h3>
                                    <?php echo e($event->checkIn); ?>

                                </h3>
                                <p>Compareceram</p>
                            </div>
                            <div class="attended" id="invited">
                                <h3>
                                    <?php echo e($event->invited); ?>

                                </h3>
                                <p>Convidados</p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<script>
    function showMenu(el) {
        const menu = el.nextElementSibling

        if(menu.classList.contains('hidden')){
            menu.classList.remove('hidden')
        } else {
            menu.classList.add('hidden')
        }
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/home.blade.php ENDPATH**/ ?>