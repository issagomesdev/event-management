<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/events/styles.css">
    <script src="https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"></script>
    <title><?php echo e(trans('panel.site_title')); ?> - Eventos </title>
</head>
<body>

    <?php echo $__env->make('public.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h2>Eventos</h2>
    
</body>
</html><?php /**PATH C:\laragon\www\event-management\resources\views/public/events/index.blade.php ENDPATH**/ ?>