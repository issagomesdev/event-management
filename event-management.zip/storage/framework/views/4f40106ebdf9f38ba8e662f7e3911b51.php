<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/styles.css">
    <title><?php echo e(trans('panel.site_title')); ?> - Eventos </title>
</head>
<body>

    <?php echo $__env->make('public.partials.header', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section id="events">
        <div class="content">
            <h2>Eventos</h2>
            <div class="items">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/event-details/<?php echo e($event->id); ?>/<?php echo e(str_replace(' ', '-', $event->name)); ?>">
                        <div class="item">
                            <?php if(isset($event->cover)): ?>
                            <div class="cover" style="background-image: url('<?php echo e($event->cover->getUrl()); ?>');">
                            </div>
                            <?php else: ?> 
                            <div class="cover default" style="background-image: url('<?php echo e(asset('images/logo.png')); ?>');">
                            </div>
                            <?php endif; ?>
                            <div class="info">
                                <h3><?php echo e($event->name); ?></h3>
                                <p>Inicio: <?php echo e($event->start); ?> <?php echo e($event->start_time); ?></p>
                                <p>Fim: <?php echo e($event->end); ?> <?php echo e($event->end_time); ?></p>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </section>

    
    
</body>
</html>
<?php /**PATH C:\laragon\www\event-management\resources\views/public/index.blade.php ENDPATH**/ ?>