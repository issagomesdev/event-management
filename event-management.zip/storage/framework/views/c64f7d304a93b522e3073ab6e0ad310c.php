<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/custom.css">
    <title><?php echo e(trans('panel.site_title')); ?></title>
</head>
<body>
    <?php echo $__env->make('public.partials.header', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table table-bordered table-striped" id="full-data">
        <tbody>
            <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($key+1); ?> - <?php echo e($item->name); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="attendances">
        <div class="infos">
            <h2>Lista de presença do evento</h2>
            <div class="actions">
                <div class="save" id="toPDF" onclick="exportToPDF()">
                    <iconify-icon icon="ic:round-file-download"></iconify-icon>
                    <span>Baixar PDF</span>
                </div>
                <div class="save" id="toCSV" onclick="exportToCSV()">
                    <iconify-icon icon="ph:file-csv-duotone"></iconify-icon>
                    <span>Exportar CSV</span>
                </div>
                <div class="save" id="groupBy_clients" onclick="groupList(this)">
                    <iconify-icon icon="heroicons:user-group-16-solid"></iconify-icon>
                    <span>Agrupar por nome</span>
                </div>
                <div class="save" id="orderBy_id" onclick="orderList(this)">
                    <iconify-icon icon="mdi:order-alphabetical-ascending"></iconify-icon>
                    <span>Ordenação Alfabetica</span>
                </div>
            </div>
        </div>
        <div class="list">
            <?php $__currentLoopData = $attendanceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <h4>
                        <p><?php echo e($list->name); ?> <?php echo e($list->surname); ?> 
                            <?php if(count($list->guests) > 0): ?>
                            <iconify-icon class="show-guests" onclick="showGuests(this)" icon="bxs:right-arrow"></iconify-icon> 
                            <?php endif; ?>
                        </p>
                    </h4>
                        <?php if(count($list->guests) > 0): ?>
                        <div class="guests">
                            <?php $__currentLoopData = $list->guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="guest">
                                <p><?php echo e($guest->guest); ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <h2><?php echo e($attendanceCheckInCount); ?> Compareceram de <?php echo e($attendanceCount); ?> Convidados</h2>
    </div>
</body>
</html>

<script src="/js/jspdf/jspdf.umd.js"></script>
<script src="/js/jspdf/jspdf.plugin.autotable.js"></script>

<script>

    let groupby = 'clients';
    let orderby = 'id';

    function showGuests(el) {
        
        console.log(el, el.closest(".item"))
        var showEl = el.closest(".item").querySelector(".guests");
        if(showEl.classList.contains('show')){
            showEl.classList.remove('show');
            el.icon="bxs:right-arrow";
        } else {
            showEl.classList.add('show')
            el.icon="bxs:down-arrow";
        }
    }

	function exportToPDF() {
		var doc = new jspdf.jsPDF()

        doc.text('Lista de presença - <?php echo e($event->name); ?>', 15, 15);
		doc.autoTable({ html: 'table#full-data', startY: 20 })

		doc.save('lista_<?php echo e($event->name); ?>.pdf')
	}

	function exportToCSV() {
		var table = document.querySelector('table#full-data');
		var csvData = [
            <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            {
                Nome: "<?php echo e($item->name); ?>"
            },
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
        
        const header = Object.keys(csvData[0]).join(',') + '\n';
        const rows = csvData.map(obj => Object.values(obj).join(',')).join('\n');
    	const blob = new Blob([header + rows], { type: 'text/csv' });
		const link = document.createElement('a');
		link.href = URL.createObjectURL(blob);
		link.download = 'lista_<?php echo e($event->name); ?>.csv';
		document.body.appendChild(link);
    	link.click();
	}

    function groupList(el) {
        if(el.id === "groupBy_clients") {
            el.id = "groupBy_name";
            groupby = "name";
        } else {
            el.id = "groupBy_clients";
            groupby = "clients";
        }

        reloadList()
    }

    function orderList(el) {

        if(el.id === "orderBy_id") {
            el.id = "orderBy_abc";
            orderby = "abc";
        } else {
            el.id = "orderBy_id";
            orderby = "id";
            
        }
        
        reloadList()
    }

    function reloadList() {
        const listEl = document.querySelector('.list');

        let list = [];

        if(groupby === "clients") {
            list = [
                <?php $__currentLoopData = $attendanceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    id: <?php echo e($key+1); ?>,
                    name: "<?php echo e($list->name); ?> <?php echo e($list->surname); ?>",
                    guest: [
                    <?php $__currentLoopData = $list->guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           {
                            id: <?php echo e($key+1); ?>,
                            name: "<?php echo e($guest->guest); ?>",
                           }, 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ],
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        } else {
            list = [
                <?php $__currentLoopData = $attendanceListFull; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    id: <?php echo e($key+1); ?>,
                    name: "<?php echo e($list->name); ?>",
                    type: "<?php echo e($list->type); ?>"
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        }

        if(orderby === "id"){
            list.sort((a, b) => a.id - b.id);
        } else {
            list.sort((a, b) => a.name.localeCompare(b.name));
        }

        listEl.innerHTML = `${list.map(function(item) {
                        return `<div class="item">
                            <h4> <p>${item.name} 
                                ${item.guest && item.guest.length > 0? '<iconify-icon class="show-guests" onclick="showGuests(this)" icon="bxs:right-arrow"></iconify-icon>' : ''}
                                </p> 
                            </h4>
                            ${item.guest && item.guest.length > 0? `
                            <div class="guests">
                            ${item.guest.map(function(guest) {
                            return `<div class="guest">
                                    <p>${guest.name}</p>
                                </div>`
                            }).join('')}
                            </div>
                            ` : '' }
                            </div>`
                        }).join('')}`
        
    }

</script><?php /**PATH C:\laragon\www\event-management\resources\views/public/events/list.blade.php ENDPATH**/ ?>