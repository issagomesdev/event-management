<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.event.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.events.update", [$event->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="photo"><?php echo e(trans('cruds.event.fields.photo')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                </div>
                <?php if($errors->has('photo')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.photo_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="cover"><?php echo e(trans('cruds.event.fields.cover')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('cover') ? 'is-invalid' : ''); ?>" id="cover-dropzone">
                </div>
                <?php if($errors->has('cover')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cover')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.cover_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.event.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $event->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.name_helper')); ?></span>
            </div>
            <div class="form-collection">
                <div class="form-group full">
                    <label for="start"><?php echo e(trans('cruds.event.fields.start')); ?></label>
                    <input class="form-control date <?php echo e($errors->has('start') ? 'is-invalid' : ''); ?>" type="text" name="start" id="start" value="<?php echo e(old('start', $event->start)); ?>">
                    <?php if($errors->has('start')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('start')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.start_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="start_time"><?php echo e(trans('cruds.event.fields.start_time')); ?></label>
                    <input class="form-control timepicker <?php echo e($errors->has('start_time') ? 'is-invalid' : ''); ?>" type="text" name="start_time" id="start_time" value="<?php echo e(old('start_time', $event->start_time)); ?>">
                    <?php if($errors->has('start_time')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('start_time')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.start_time_helper')); ?></span>
                </div>
            </div>
            <div class="form-collection">  
                <div class="form-group full">
                    <label for="end"><?php echo e(trans('cruds.event.fields.end')); ?></label>
                    <input class="form-control date <?php echo e($errors->has('end') ? 'is-invalid' : ''); ?>" type="text" name="end" id="end" value="<?php echo e(old('end', $event->end)); ?>">
                    <?php if($errors->has('end')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('end')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.end_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="end_time"><?php echo e(trans('cruds.event.fields.end_time')); ?></label>
                    <input class="form-control timepicker <?php echo e($errors->has('end_time') ? 'is-invalid' : ''); ?>" type="text" name="end_time" id="end_time" value="<?php echo e(old('end_time', $event->end_time)); ?>">
                    <?php if($errors->has('end_time')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('end_time')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.end_time_helper')); ?></span>
                </div>
            </div>
            <div class="form-collection">   
                <div class="form-group">
                    <label for="country"><?php echo e(trans('cruds.event.fields.country')); ?></label>
                    <input class="form-control <?php echo e($errors->has('country') ? 'is-invalid' : ''); ?>" type="text" name="country" id="country" value="<?php echo e(old('country', $event->country)); ?>">
                    <?php if($errors->has('country')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('country')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.country_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="state"><?php echo e(trans('cruds.event.fields.state')); ?></label>
                    <input class="form-control <?php echo e($errors->has('state') ? 'is-invalid' : ''); ?>" type="text" name="state" id="state" value="<?php echo e(old('state', $event->state)); ?>">
                    <?php if($errors->has('state')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('state')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.state_helper')); ?></span>
                </div>
            </div>
            <div class="form-collection">  
                <div class="form-group">
                    <label for="city"><?php echo e(trans('cruds.event.fields.city')); ?></label>
                    <input class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>" type="text" name="city" id="city" value="<?php echo e(old('city', $event->city)); ?>">
                    <?php if($errors->has('city')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('city')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.city_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="neighborhood"><?php echo e(trans('cruds.event.fields.neighborhood')); ?></label>
                    <input class="form-control <?php echo e($errors->has('neighborhood') ? 'is-invalid' : ''); ?>" type="text" name="neighborhood" id="neighborhood" value="<?php echo e(old('neighborhood', $event->neighborhood)); ?>">
                    <?php if($errors->has('neighborhood')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('neighborhood')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.neighborhood_helper')); ?></span>
                </div>
            </div>
            <div class="form-collection">
                <div class="form-group">
                    <label for="street"><?php echo e(trans('cruds.event.fields.street')); ?></label>
                    <input class="form-control <?php echo e($errors->has('street') ? 'is-invalid' : ''); ?>" type="text" name="street" id="street" value="<?php echo e(old('street', $event->street)); ?>">
                    <?php if($errors->has('street')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('street')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.street_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="number"><?php echo e(trans('cruds.event.fields.number')); ?></label>
                    <input class="form-control <?php echo e($errors->has('number') ? 'is-invalid' : ''); ?>" type="text" name="number" id="number" value="<?php echo e(old('number', $event->number)); ?>">
                    <?php if($errors->has('number')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('number')); ?>

                        </div>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.event.fields.number_helper')); ?></span>
                </div>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.event.fields.description')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo old('description', $event->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="rules"><?php echo e(trans('cruds.event.fields.rules')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('rules') ? 'is-invalid' : ''); ?>" name="rules" id="rules"><?php echo old('rules', $event->rules); ?></textarea>
                <?php if($errors->has('rules')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('rules')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.rules_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="link"><?php echo e(trans('cruds.event.fields.link')); ?></label>
                <input class="form-control <?php echo e($errors->has('link') ? 'is-invalid' : ''); ?>" type="text" name="link" id="link" value="<?php echo e(old('link', $event->link)); ?>">
                <?php if($errors->has('link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="link_instruction"><?php echo e(trans('cruds.event.fields.link_instruction')); ?></label>
                <input class="form-control <?php echo e($errors->has('link_instruction') ? 'is-invalid' : ''); ?>" type="text" name="link_instruction" id="link_instruction" value="<?php echo e(old('link_instruction', $event->link_instruction)); ?>">
                <?php if($errors->has('link_instruction')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('link_instruction')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.link_instruction_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="pixel"><?php echo e(trans('cruds.event.fields.pixel')); ?></label>
                <input class="form-control <?php echo e($errors->has('pixel') ? 'is-invalid' : ''); ?>" type="text" name="pixel" id="pixel" value="<?php echo e(old('pixel', $event->pixel)); ?>">
                <?php if($errors->has('pixel')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('pixel')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.pixel_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="whatsapp"><?php echo e(trans('cruds.event.fields.whatsapp')); ?></label>
                <input class="form-control <?php echo e($errors->has('whatsapp') ? 'is-invalid' : ''); ?>" type="text" name="whatsapp" id="whatsapp" value="<?php echo e(old('whatsapp', $event->whatsapp)); ?>">
                <?php if($errors->has('whatsapp')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('whatsapp')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.whatsapp_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="whatsappmessage"><?php echo e(trans('cruds.event.fields.whatsappmessage')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('whatsappmessage') ? 'is-invalid' : ''); ?>" name="whatsappmessage" id="whatsappmessage"><?php echo e(old('whatsappmessage', $event->whatsappmessage)); ?></textarea>
                <?php if($errors->has('whatsappmessage')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('whatsappmessage')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.whatsappmessage_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.event.fields.visualization')); ?></label>
                <?php $__currentLoopData = App\Models\Event::VISUALIZATION_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('visualization') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="visualization_<?php echo e($key); ?>" name="visualization" value="<?php echo e($key); ?>" <?php echo e(old('visualization', $event->visualization) === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="visualization_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('visualization')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('visualization')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.visualization_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.event.fields.type')); ?></label>
                <?php $__currentLoopData = App\Models\Event::TYPE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('type') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="type_<?php echo e($key); ?>" name="type" value="<?php echo e($key); ?>" <?php echo e(old('type', $event->type) === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="type_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.type_helper')); ?></span>
            </div>
            <div class="form-group" style="display: <?php echo e($event->type === '0'? 'block' : 'none'); ?>">
                <label for="capacity"><?php echo e(trans('cruds.event.fields.capacity')); ?></label>
                <input class="form-control <?php echo e($errors->has('capacity') ? 'is-invalid' : ''); ?>" type="number" name="capacity" id="capacity" value="<?php echo e(old('capacity', $event->capacity)); ?>" step="1" <?php echo e($event->type === '0'? 'required' : ''); ?>>
                <?php if($errors->has('capacity')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('capacity')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.capacity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.event.fields.allow_guests')); ?></label>
                <?php $__currentLoopData = App\Models\Event::ALLOW_GUESTS_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check <?php echo e($errors->has('allow_guests') ? 'is-invalid' : ''); ?>">
                        <input class="form-check-input" type="radio" id="allow_guests_<?php echo e($key); ?>" name="allow_guests" value="<?php echo e($key); ?>" <?php echo e(old('allow_guests', $event->allow_guests) === (string) $key ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="allow_guests_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('allow_guests')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('allow_guests')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.allow_guests_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    let typeRadios = document.querySelectorAll("[name=type]");

    typeRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            const capacity = document.querySelector('input#capacity'); 
            const formGroup = capacity.closest('.form-group');
            if(this.value == 1){
                capacity.value = '';
                capacity.removeAttribute("required");
                formGroup.style.display = 'none';
            } else {
                formGroup.style.display = 'block';
                capacity.setAttribute("required", "");
            }
        });
    });

</script>
<script>
    var uploadedPhotoMap = {}
Dropzone.options.photoDropzone = {
    url: '<?php echo e(route('admin.events.storeMedia')); ?>',
    maxFilesize: 5, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').append('<input type="hidden" name="photo[]" value="' + response.name + '">')
      uploadedPhotoMap[file.name] = response.name
    },
    removedfile: function (file) {
      console.log(file)
      file.previewElement.remove()
      var name = ''
      if (typeof file.file_name !== 'undefined') {
        name = file.file_name
      } else {
        name = uploadedPhotoMap[file.name]
      }
      $('form').find('input[name="photo[]"][value="' + name + '"]').remove()
    },
    init: function () {
<?php if(isset($event) && $event->photo): ?>
      var files = <?php echo json_encode($event->photo); ?>

          for (var i in files) {
          var file = files[i]
          this.options.addedfile.call(this, file)
          this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
          file.previewElement.classList.add('dz-complete')
          $('form').append('<input type="hidden" name="photo[]" value="' + file.file_name + '">')
        }
<?php endif; ?>
    },
     error: function (file, response) {
         if ($.type(response) === 'string') {
             var message = response //dropzone sends it's own error messages in string
         } else {
             var message = response.errors.file
         }
         file.previewElement.classList.add('dz-error')
         _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
         _results = []
         for (_i = 0, _len = _ref.length; _i < _len; _i++) {
             node = _ref[_i]
             _results.push(node.textContent = message)
         }

         return _results
     }
}

</script>
<script>
    Dropzone.options.coverDropzone = {
    url: '<?php echo e(route('admin.events.storeMedia')); ?>',
    maxFilesize: 5, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 5,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="cover"]').remove()
      $('form').append('<input type="hidden" name="cover" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="cover"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($event) && $event->cover): ?>
      var file = <?php echo json_encode($event->cover); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview ?? file.preview_url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="cover" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}

</script>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.events.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($event->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>