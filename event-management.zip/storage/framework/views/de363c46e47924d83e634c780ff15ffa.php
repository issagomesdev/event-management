<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/css/events/styles.css">
    <title><?php echo e(trans('panel.site_title')); ?></title>
</head>
<body>
    <?php echo $__env->make('public.partials.header', ['user' => $user], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="warning-container" id="sucess">
        <iconify-icon icon="iconoir:check-circle-solid" id="sucess"></iconify-icon>
        <iconify-icon icon="material-symbols-light:error-rounded" id="error"></iconify-icon>
        <div class="message">
            <h3></h3>
            <p></p>
        </div>
    </div>
    <div class="container">
        <div class="recipient">
            <div class="content">
                <div class="main-info">
                    <h3><?php echo e($event->name); ?></h3>
                    <p> <?php echo e($event->start); ?> <?php echo e($event->start_time); ?> - <?php echo e($event->end); ?> <?php echo e($event->end_time); ?></p>
                </div>
            </div>
            <?php if(count($event->photo) > 0): ?>
            <div class="gallery">
                <div class="photos <?php echo e(count($event->photo) <= 1? 'lonely' : ''); ?>">
                    <div class="featured">
                        <img src="<?php echo e($event->photo[0]->getUrl()); ?>">
                    </div>
                    <?php if(count($event->photo) > 1): ?>
                    <div class="images">  
                        <div class="items">
                            <?php $__currentLoopData = $event->photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e($photo->getUrl()); ?>" draggable="false" onclick="setFeatured(this)" id="i<?php echo e($key+1); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <iconify-icon class="controls" icon="uiw:left-circle" id="left"></iconify-icon>
                    <iconify-icon class="controls" icon="uiw:right-circle" id="right"> </iconify-icon>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
            <?php if($event->description): ?>
            <div class="content">   
                <div class="info">
                    <h3>Descrição</h3>
                    <p><?php echo $event->description; ?></p>
                </div>
            </div>
            <?php endif; ?>
            <?php if($event->rules): ?>
            <div class="content">   
                <div class="info">
                    <h3>Regulamento</h3>
                    <p><?php echo $event->rules; ?></p>
                </div>
            </div>
            <?php endif; ?>
            <?php if($event->link): ?>
            <div class="content">   
                <div class="info">
                    <h3>Link</h3>
                    <p><?php echo e($event->link_instruction); ?> <a href="<?php echo e($event->link); ?>"><?php echo e($event->link); ?></a></p>
                </div>
            </div>
            <?php endif; ?>
            <?php if($event->pixel): ?>
            <div class="content">   
                <div class="info">
                    <h3>Pixel</h3>
                    <p><?php echo e($event->pixel); ?></p>
                </div>
            </div>
            <?php endif; ?>
            <?php if($open): ?> 
                <div class="attendance" id="attendance">
                    <?php if($attendance): ?>

                        <?php if($event->allow_guests === '1'): ?>
                            <div class="guests">
                                <div class="content">
                                    <div class="info">
                                        <h3 id="sucess">Sua presença foi confirmada com sucesso!</h3>
                                        <?php if($event->type !== '1' && $event->capacity <= $attendanceCount): ?>
                                            <h4>Este evento atingiu sua capacidade máxima!</h4>
                                        <?php endif; ?>
                                        <h4 style="<?php echo e($event->type !== '1' && $event->capacity <= $attendanceCount? 'display: none;' : ''); ?>">Deseja Incluir amigos(as)?</h4>
                                        <?php if($event->type === '1' || $event->capacity > $attendanceCount): ?>
                                        <div class="guest-include">
                                            <input type="text" placeholder="Nome Sobrenome">
                                            <div class="actions">
                                                <div class="action" id="save" onclick="saveGuest()">
                                                    <iconify-icon icon="icon-park-solid:check-one"></iconify-icon>
                                                    <span>incluir</span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <h4>Nomes Confirmados:</h4>
                                        <div class="list">
                                            <div class="guest">
                                                <p><?php echo e($user->name); ?> <?php echo e($user->surname); ?> (você)</p>
                                            </div>
                                            <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="guest" id="i<?php echo e($key+1); ?>">
                                                    <p><?php echo e($guest->guest); ?></p>
                                                    <div class="actions">
                                                        <div class="action" id="delete" onclick="deleteGuest(<?php echo e($key+1); ?>)">
                                                            <iconify-icon icon="ic:round-delete-sweep"></iconify-icon>
                                                            <span>excluir</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <?php if($event->type === '1' || $event->capacity > $attendanceCount): ?>
                                            <div class="actions">
                                                
                                                <?php if(count($guests) < 1): ?>
                                                <button id="save-guests" onclick="saveGuests()">Ativar minha lista e finalizar</button>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="content">
                                <div class="info sucess">
                                    <h3 id="sucess">Sua presença foi confirmada com sucesso!</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    <?php else: ?>

                        <?php if($event->type === '1' || $event->capacity > $attendanceCount): ?>
                            <form action="<?php echo e(route('confirm.attendance.event', $event->id)); ?>" method="POST" onsubmit="return confirm('Confirmar presença no evento?');" style="display: inline-block;">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <input type="submit" id="confirm" value="Confirmar presença">
                            </form>
                        <?php else: ?>
                            <div class="content">
                                <div class="info alert">
                                    <h4>Este evento atingiu sua capacidade máxima!</h4>
                                </div>
                            </div>
                        <?php endif; ?>

                    <?php endif; ?>
                </div>
            <?php else: ?>

                <div class="content">
                    <div class="info alert">
                        <?php if($attendance): ?>
                        <h3 id="sucess">Sua presença foi confirmada com sucesso!</h3>
                        <?php endif; ?>
                        <h4>Evento encerrado!</h4>
                    </div>
                </div>

            <?php endif; ?>
            
            <div class="content" style="margin-top: .5em">
                <div class="info">
                    <div class="figure">
                        <div href="https://www.google.com/maps/search/?api=1&query=<?php echo e($event->number); ?>,<?php echo e($event->street); ?>,<?php echo e($event->neighborhood); ?>,<?php echo e($event->city); ?>,<?php echo e($event->state); ?>,<?php echo e($event->country); ?>" class="location">
                            <iconify-icon icon="mingcute:location-fill"></iconify-icon>
                        </div>
                        <div class="info">
                            <h3>Local</h3>
                            <p><?php echo e($event->street); ?>, <?php echo e($event->number); ?>, <?php echo e($event->neighborhood); ?>, <?php echo e($event->city); ?> - <?php echo e($event->state); ?> <?php echo e($event->country); ?> <span onclick="copyText()">copiar</span></p>
                        </div>
                    </div>
                    <?php if($attendance): ?>
                    <iframe id="map" width="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<script>

function getCoordinates() {
           fetch(`https://nominatim.openstreetmap.org/search?q=<?php echo e($address); ?>&format=json&limit=1`)
                .then(response => response.json())
                .then(data => {
                    if (data.length > 0) {
                        const { lat, lon } = data[0];
                        const map = document.querySelector("iframe#map");
                        map.src = `https://www.openstreetmap.org/export/embed.html?bbox=${lon},${lat},${lon},${lat}&layer=mapnik`
                    } else {
                        console.error('Endereço não encontrado');
                    }
                })
                .catch(error =>console.error('Erro:', error));
        }
        
        <?php if($attendance): ?> getCoordinates() <?php endif; ?>

    function warning(title, text, type) {
        const warning = document.querySelector(`.warning-container`);
        warning.id = type;
        warning.querySelector("h3").innerHTML = title;
        warning.querySelector("p").innerHTML = text;
        warning.style.display = "flex";
        setTimeout(() => {
            warning.style.display = "none";
        }, 5000);

        const allow_guests = <?php echo e($event->allow_guests); ?>;
        console.log(text, allow_guests)
        if((text == "Presença confirmada com sucesso!" && allow_guests == 0) || text == "Lista salva com sucesso!" ) {
            redirectWhatsapp();
        }
    }

    <?php if(session('success')): ?>
    warning("Sucesso", "<?php echo e(session('success')); ?>", "sucess");
    <?php endif; ?>

    <?php if(session('error')): ?>
    warning("Falha", "<?php echo e(session('error')); ?>", "error");
    <?php endif; ?>

    const guests = [
        <?php $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        {
            id: <?php echo e($key+1); ?>,
            guestID: <?php echo e($guest->id); ?>,
            name: "<?php echo e($guest->guest); ?>"
        },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($guests) < 1 && ($event->type === '1' || $event->capacity > $attendanceCount)): ?>
        {
            id: 1,
            name: ""
        }
        <?php endif; ?>
    ];

    let increment = <?php echo e(count($guests) >= 1? count($guests) : 1); ?>;

    const guestsEl = document.querySelector('.guests .list');
    const includeField = document.querySelector('.guest-include input');

    function saveGuest() {
            let value = includeField.value.trim();
            if(value.length !== 0){
                
                const url = `<?php echo e(route('add.guest.event', ['eventID' => $event->id, 'customerID' => $user->id ?? 0])); ?>`;
        
                fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json', 
                        'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                    },
                    body: JSON.stringify({
                        name: includeField.value
                    })
                })
                .then(response => response.json())
                .then(data => {
                    increment++
                    guests.push({ id: increment, name: includeField.value, guestID: data.guestID });
                    const guestEl = document.createElement('div');
                    guestEl.innerHTML = `<p>${includeField.value}</p>
                                            <div class="actions">
                                                <div class="action" id="delete" onclick="deleteGuest(${increment})">
                                                    <iconify-icon icon="ic:round-delete-sweep"></iconify-icon>
                                                    <span>excluir</span>
                                                </div>
                                            </div>`;
                    guestEl.classList.add('guest');
                    guestEl.id = `i${increment}`;
                    guestsEl.appendChild(guestEl);
                    includeField.value = "";
                })
                .catch((error) => {
                    console.error('There was a problem with the fetch operation:', error);
                });

                
            } else {
                alert("Preencha o nome do(a) convidado(a)!")
            }
    }

    function deleteGuest(id) {
        let result = confirm("Remover convidado(a)?");

        if(result){
            const index = guests.findIndex(g => g.id == id);
            if (index !== -1) {
                
            const url = `<?php echo e(route('delete.guest.event', ['guestID' => ':guestID'])); ?>`
            .replace(':guestID', guests[index].guestID);
        
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json', 
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                }
            })
            .then(response => response.json())
            .then(data => {
                guests.splice(index, 1)
                const guestEl = document.querySelector(`.guest#i${id}`);
                if(guestEl) guestEl.remove();
            })
            .catch((error) => {
                console.error('There was a problem with the fetch operation:', error);
            });
            }
        }
    }

    async function redirectWhatsapp() {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = "<?php echo e(route('redirect.whatsapp')); ?>";
        let csrfTokenField = document.createElement('input');
        csrfTokenField.type = 'hidden';
        csrfTokenField.name = '_token';
        csrfTokenField.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrfTokenField)

        let whatsapp = document.createElement('input');
        whatsapp.type = 'hidden';
        whatsapp.name = 'whatsapp';
        whatsapp.value = '<?php echo e($event->whatsapp); ?>';
        form.appendChild(whatsapp);

        let message = document.createElement('input');
        message.type = 'hidden';
        message.name = 'message';
        message.value = '<?php echo e($event->whatsappmessage); ?>';
        form.appendChild(message);
        
        document.body.appendChild(form);
        form.submit();
    }

    async function saveGuests() {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = "<?php echo e(route('save.guests.event', $event->id)); ?>";

        let csrfTokenField = document.createElement('input');
        csrfTokenField.type = 'hidden';
        csrfTokenField.name = '_token';
        csrfTokenField.value = '<?php echo e(csrf_token()); ?>';
        form.appendChild(csrfTokenField)

            // let guestsField = document.createElement('input');
            // guestsField.type = 'hidden';
            // guestsField.name = 'guests';
            // guestsField.value = JSON.stringify(guests);
            // form.appendChild(guestsField);

        document.body.appendChild(form);
        form.submit();
    }

    function copyText() {
            const text = '<?php echo e($event->street); ?>, <?php echo e($event->number); ?>, <?php echo e($event->neighborhood); ?>, <?php echo e($event->city); ?> - <?php echo e($event->state); ?> <?php echo e($event->country); ?>';

            const textarea = document.createElement('textarea');
            textarea.value = text;
            document.body.appendChild(textarea);
            textarea.select();
            try {
                const sucess = document.execCommand('copy');
                if (sucess) {
                    warning("Sucesso", "Texto copiado!", "sucess");
                } else {
                    warning("Falha", "Texto não copiado", "error");
                }
            } catch (err) {
                console.error('Erro ao tentar copiar o texto: ', err);
                warning("Falha", "Texto não copiado", "error");
            }
            document.body.removeChild(textarea);
        }
    
</script>
<?php if(count($event->photo) > 1): ?> 
<script>
    const leftControl = document.querySelector("iconify-icon#left");
    const rightControl = document.querySelector("iconify-icon#right");
    const featured = document.querySelector(".featured img");
    imagesTotal = <?php echo e(count($event->photo)); ?>;
    currentImage = 1;

    function setFeatured(el) {
        featured.src = el.src;
    }

    leftControl.addEventListener("click", () => { 
        let image;

        if(currentImage === 1) currentImage = imagesTotal
        else currentImage--

        image = document.querySelector(`.items img#i${currentImage}`)
        featured.src = image.src;
    });

    rightControl.addEventListener("click", () => { 
        let image;

        if(currentImage === imagesTotal) currentImage = 1
        else currentImage++

        image = document.querySelector(`.items img#i${currentImage}`)
        featured.src = image.src;
    });
</script>
<?php endif; ?><?php /**PATH C:\laragon\www\event-management\resources\views/public/events/details.blade.php ENDPATH**/ ?>