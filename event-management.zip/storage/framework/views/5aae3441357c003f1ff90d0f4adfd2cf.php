<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700|Raleway:300,600" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>
    <link rel="stylesheet" href="/css/customer-form.css">
    <title><?php echo e(trans('panel.site_title')); ?></title>
</head>
<body>
   <div class="container">
      <?php if($register): ?>
         <section id="formHolder">
            <div class="row">
               <div class="col-sm-6 brand">
                  
                  <div class="logo">
                     <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Listinha VIP">
                  </div>
                  <div class="heading">
                     <h2>Bem-vindo </h2>
                     <p>Realize seu cadastro para visualizar o evento</p>
                  </div>
               </div>
               <div class="col-sm-6 form">
                  <div class="login form-peice">
                     <form class="login-form" method="POST" action="<?php echo e(route("customers.store")); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                           <label for="whatsApp">Numero do whatsApp</label>
                           <div class="associate">
                              <span>+</span>
                              <input name="code" id="code" value="<?php echo e(old('code') ?? $code ?? '55'); ?>" required>
                              <?php $selectedDdd = old('ddd') ?? $ddd ?? '85'; ?>
                              <select name="ddd" id="ddd">
                                 <option value="68" <?php echo e($selectedDdd == '68' ? 'selected' : ''); ?>>68</option>
                                 <option value="96" <?php echo e($selectedDdd == '96' ? 'selected' : ''); ?>>96</option>
                                 <option value="92" <?php echo e($selectedDdd == '92' ? 'selected' : ''); ?>>92</option>
                                 <option value="97" <?php echo e($selectedDdd == '97' ? 'selected' : ''); ?>>97</option>
                                 <option value="91" <?php echo e($selectedDdd == '91' ? 'selected' : ''); ?>>91</option>
                                 <option value="93" <?php echo e($selectedDdd == '93' ? 'selected' : ''); ?>>93</option>
                                 <option value="94" <?php echo e($selectedDdd == '94' ? 'selected' : ''); ?>>94</option>
                                 <option value="69" <?php echo e($selectedDdd == '69' ? 'selected' : ''); ?>>69</option>
                                 <option value="95" <?php echo e($selectedDdd == '95' ? 'selected' : ''); ?>>95</option>
                                 <option value="63" <?php echo e($selectedDdd == '63' ? 'selected' : ''); ?>>63</option>
                                 <option value="82" <?php echo e($selectedDdd == '82' ? 'selected' : ''); ?>>82</option>
                                 <option value="71" <?php echo e($selectedDdd == '71' ? 'selected' : ''); ?>>71</option>
                                 <option value="73" <?php echo e($selectedDdd == '73' ? 'selected' : ''); ?>>73</option>
                                 <option value="74" <?php echo e($selectedDdd == '74' ? 'selected' : ''); ?>>74</option>
                                 <option value="75" <?php echo e($selectedDdd == '75' ? 'selected' : ''); ?>>75</option>
                                 <option value="77" <?php echo e($selectedDdd == '77' ? 'selected' : ''); ?>>77</option>
                                 <option value="85" <?php echo e($selectedDdd == '85' ? 'selected' : ''); ?>>85</option>
                                 <option value="88" <?php echo e($selectedDdd == '88' ? 'selected' : ''); ?>>88</option>
                                 <option value="98" <?php echo e($selectedDdd == '98' ? 'selected' : ''); ?>>98</option>
                                 <option value="99" <?php echo e($selectedDdd == '99' ? 'selected' : ''); ?>>99</option>
                                 <option value="83" <?php echo e($selectedDdd == '83' ? 'selected' : ''); ?>>83</option>
                                 <option value="81" <?php echo e($selectedDdd == '81' ? 'selected' : ''); ?>>81</option>
                                 <option value="87" <?php echo e($selectedDdd == '87' ? 'selected' : ''); ?>>87</option>
                                 <option value="86" <?php echo e($selectedDdd == '86' ? 'selected' : ''); ?>>86</option>
                                 <option value="89" <?php echo e($selectedDdd == '89' ? 'selected' : ''); ?>>89</option>
                                 <option value="84" <?php echo e($selectedDdd == '84' ? 'selected' : ''); ?>>84</option>
                                 <option value="79" <?php echo e($selectedDdd == '79' ? 'selected' : ''); ?>>79</option>
                                 <option value="61" <?php echo e($selectedDdd == '61' ? 'selected' : ''); ?>>61</option>
                                 <option value="62" <?php echo e($selectedDdd == '62' ? 'selected' : ''); ?>>62</option>
                                 <option value="64" <?php echo e($selectedDdd == '64' ? 'selected' : ''); ?>>64</option>
                                 <option value="65" <?php echo e($selectedDdd == '65' ? 'selected' : ''); ?>>65</option>
                                 <option value="66" <?php echo e($selectedDdd == '66' ? 'selected' : ''); ?>>66</option>
                                 <option value="67" <?php echo e($selectedDdd == '67' ? 'selected' : ''); ?>>67</option>
                                 <option value="27" <?php echo e($selectedDdd == '27' ? 'selected' : ''); ?>>27</option>
                                 <option value="28" <?php echo e($selectedDdd == '28' ? 'selected' : ''); ?>>28</option>
                                 <option value="31" <?php echo e($selectedDdd == '31' ? 'selected' : ''); ?>>31</option>
                                 <option value="32" <?php echo e($selectedDdd == '32' ? 'selected' : ''); ?>>32</option>
                                 <option value="33" <?php echo e($selectedDdd == '33' ? 'selected' : ''); ?>>33</option>
                                 <option value="34" <?php echo e($selectedDdd == '34' ? 'selected' : ''); ?>>34</option>
                                 <option value="35" <?php echo e($selectedDdd == '35' ? 'selected' : ''); ?>>35</option>
                                 <option value="37" <?php echo e($selectedDdd == '37' ? 'selected' : ''); ?>>37</option>
                                 <option value="38" <?php echo e($selectedDdd == '38' ? 'selected' : ''); ?>>38</option>
                                 <option value="21" <?php echo e($selectedDdd == '21' ? 'selected' : ''); ?>>21</option>
                                 <option value="22" <?php echo e($selectedDdd == '22' ? 'selected' : ''); ?>>22</option>
                                 <option value="24" <?php echo e($selectedDdd == '24' ? 'selected' : ''); ?>>24</option>
                                 <option value="11" <?php echo e($selectedDdd == '11' ? 'selected' : ''); ?>>11</option>
                                 <option value="12" <?php echo e($selectedDdd == '12' ? 'selected' : ''); ?>>12</option>
                                 <option value="13" <?php echo e($selectedDdd == '13' ? 'selected' : ''); ?>>13</option>
                                 <option value="14" <?php echo e($selectedDdd == '14' ? 'selected' : ''); ?>>14</option>
                                 <option value="15" <?php echo e($selectedDdd == '15' ? 'selected' : ''); ?>>15</option>
                                 <option value="16" <?php echo e($selectedDdd == '16' ? 'selected' : ''); ?>>16</option>
                                 <option value="17" <?php echo e($selectedDdd == '17' ? 'selected' : ''); ?>>17</option>
                                 <option value="18" <?php echo e($selectedDdd == '18' ? 'selected' : ''); ?>>18</option>
                                 <option value="19" <?php echo e($selectedDdd == '19' ? 'selected' : ''); ?>>19</option>
                                 <option value="41" <?php echo e($selectedDdd == '41' ? 'selected' : ''); ?>>41</option>
                                 <option value="42" <?php echo e($selectedDdd == '42' ? 'selected' : ''); ?>>42</option>
                                 <option value="43" <?php echo e($selectedDdd == '43' ? 'selected' : ''); ?>>43</option>
                                 <option value="44" <?php echo e($selectedDdd == '44' ? 'selected' : ''); ?>>44</option>
                                 <option value="45" <?php echo e($selectedDdd == '45' ? 'selected' : ''); ?>>45</option>
                                 <option value="46" <?php echo e($selectedDdd == '46' ? 'selected' : ''); ?>>46</option>
                                 <option value="51" <?php echo e($selectedDdd == '51' ? 'selected' : ''); ?>>51</option>
                                 <option value="53" <?php echo e($selectedDdd == '53' ? 'selected' : ''); ?>>53</option>
                                 <option value="54" <?php echo e($selectedDdd == '54' ? 'selected' : ''); ?>>54</option>
                                 <option value="55" <?php echo e($selectedDdd == '55' ? 'selected' : ''); ?>>55</option>
                                 <option value="47" <?php echo e($selectedDdd == '47' ? 'selected' : ''); ?>>47</option>
                                 <option value="48" <?php echo e($selectedDdd == '48' ? 'selected' : ''); ?>>48</option>
                                 <option value="49" <?php echo e($selectedDdd == '49' ? 'selected' : ''); ?>>49</option>
                             </select>
                               <input style="padding: 10px;" name="number" id="number" value="<?php echo e(old('number') ?? $number ?? ''); ?>" required placeholder="9 9999-9999">
                           </div>
                           <?php if($errors->has('phonenumber')): ?>
                              <div class="invalid-feedback" style="color: #ff0000">
                                    <?php echo e($errors->first('phonenumber')); ?>

                              </div>
                           <?php endif; ?>
                        </div>
                        
                        <div class="form-group">
                           <label for="name">Nome</label>
                           <div class="associate">
                              <input style="padding: 10px;" name="name" id="name" value="<?php echo e(old('name')); ?>" required>
                           </div>
                           <?php if($errors->has('name')): ?>
                              <div class="invalid-feedback" style="color: #ff0000">
                                    <?php echo e($errors->first('name')); ?>

                              </div>
                           <?php endif; ?>
                        </div>
                        <div class="form-group">
                           <label for="surname">Sobrenome</label>
                           <div class="associate">
                              <input style="padding: 10px;" name="surname" id="surname" value="<?php echo e(old('surname')); ?>" required>
                           </div>
                           <?php if($errors->has('surname')): ?>
                              <div class="invalid-feedback" style="color: #ff0000">
                                    <?php echo e($errors->first('surname')); ?>

                              </div>
                           <?php endif; ?>
                        </div>
                        <div class="form-group">
                           <label for="birthdate">Data de nascimento</label>
                           <div class="associate">
                              <input style="padding: 10px;" name="birthdate" id="birthdate" value="<?php echo e(old('birthdate') ?? $birthdate ?? ''); ?>" required placeholder="dd/mm/aaaa">
                           </div>
                           <?php if($errors->has('birthdate')): ?>
                              <div class="invalid-feedback" style="color: #ff0000">
                                    <?php echo e($errors->first('birthdate')); ?>

                              </div>
                           <?php endif; ?>
                        </div>
                        <?php if($eventID): ?>
                        <input type="hidden" name="eventID" id="eventID" value="<?php echo e($eventID); ?>">
                        <?php endif; ?>
                        <input type="hidden" name="phonenumber" id="phonenumber" value="<?php echo e(old('phonenumber') ?? $phonenumber ?? ''); ?>">
                        <div class="CTA" style="display: flex;">
                           <input type="submit" value="Cadastrar">
                           <a href="https://wa.me/5585991634968?text=Ol%C3%A1.%20Estou%20com%20d%C3%BAvidas%20no%20site%20listinha%20vip%20">Precisa de ajuda?</a>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </section>
      <?php else: ?> 
         <section id="formHolder">
            <div class="row">
               <?php if(session('error')): ?>
                  <div class="alert alert-danger">
                     <?php echo e(session('error')); ?>

                  </div>
               <?php endif; ?>
               <div class="col-sm-6 brand">
                  <div class="logo">
                     <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Listinha VIP">
                  </div>
                  <div class="heading">
                     <h2>Bem-vindo</h2>
                     <p>Faça o login para visualizar o evento</p>
                  </div>
               </div>
               <div class="col-sm-6 form">
                  <div class="login form-peice">
                     <div class="instructions">
                        <h4>Cadastre-se para acessar nossas listas</h4>
                        <h4>É rápido e 100% seguro!</h4>
                     </div>
                     <form class="login-form" method="POST" action="<?php echo e(route("customers.verifyCustomer")); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                           <label for="phonenumber">Numero do whatsApp</label>
                           <div class="associate">
                              <span>+</span>
                              <input name="code" id="code" value="<?php echo e(old('code', '55')); ?>" required>
                              <select name="ddd" id="ddd">
                                 <option value="68" <?php echo e(old('ddd', '85') == '68' ? 'selected' : ''); ?>>68</option>
                                 <option value="96" <?php echo e(old('ddd', '85') == '96' ? 'selected' : ''); ?>>96</option>
                                 <option value="92" <?php echo e(old('ddd', '85') == '92' ? 'selected' : ''); ?>>92</option>
                                 <option value="97" <?php echo e(old('ddd', '85') == '97' ? 'selected' : ''); ?>>97</option>
                                 <option value="91" <?php echo e(old('ddd', '85') == '91' ? 'selected' : ''); ?>>91</option>
                                 <option value="93" <?php echo e(old('ddd', '85') == '93' ? 'selected' : ''); ?>>93</option>
                                 <option value="94" <?php echo e(old('ddd', '85') == '94' ? 'selected' : ''); ?>>94</option>
                                 <option value="69" <?php echo e(old('ddd', '85') == '69' ? 'selected' : ''); ?>>69</option>
                                 <option value="95" <?php echo e(old('ddd', '85') == '95' ? 'selected' : ''); ?>>95</option>
                                 <option value="63" <?php echo e(old('ddd', '85') == '63' ? 'selected' : ''); ?>>63</option>
                                 <option value="82" <?php echo e(old('ddd', '85') == '82' ? 'selected' : ''); ?>>82</option>
                                 <option value="71" <?php echo e(old('ddd', '85') == '71' ? 'selected' : ''); ?>>71</option>
                                 <option value="73" <?php echo e(old('ddd', '85') == '73' ? 'selected' : ''); ?>>73</option>
                                 <option value="74" <?php echo e(old('ddd', '85') == '74' ? 'selected' : ''); ?>>74</option>
                                 <option value="75" <?php echo e(old('ddd', '85') == '75' ? 'selected' : ''); ?>>75</option>
                                 <option value="77" <?php echo e(old('ddd', '85') == '77' ? 'selected' : ''); ?>>77</option>
                                 <option value="85" <?php echo e(old('ddd', '85') == '85' ? 'selected' : ''); ?>>85</option>
                                 <option value="88" <?php echo e(old('ddd', '85') == '88' ? 'selected' : ''); ?>>88</option>
                                 <option value="98" <?php echo e(old('ddd', '85') == '98' ? 'selected' : ''); ?>>98</option>
                                 <option value="99" <?php echo e(old('ddd', '85') == '99' ? 'selected' : ''); ?>>99</option>
                                 <option value="83" <?php echo e(old('ddd', '85') == '83' ? 'selected' : ''); ?>>83</option>
                                 <option value="81" <?php echo e(old('ddd', '85') == '81' ? 'selected' : ''); ?>>81</option>
                                 <option value="87" <?php echo e(old('ddd', '85') == '87' ? 'selected' : ''); ?>>87</option>
                                 <option value="86" <?php echo e(old('ddd', '85') == '86' ? 'selected' : ''); ?>>86</option>
                                 <option value="89" <?php echo e(old('ddd', '85') == '89' ? 'selected' : ''); ?>>89</option>
                                 <option value="84" <?php echo e(old('ddd', '85') == '84' ? 'selected' : ''); ?>>84</option>
                                 <option value="79" <?php echo e(old('ddd', '85') == '79' ? 'selected' : ''); ?>>79</option>
                                 <option value="61" <?php echo e(old('ddd', '85') == '61' ? 'selected' : ''); ?>>61</option>
                                 <option value="62" <?php echo e(old('ddd', '85') == '62' ? 'selected' : ''); ?>>62</option>
                                 <option value="64" <?php echo e(old('ddd', '85') == '64' ? 'selected' : ''); ?>>64</option>
                                 <option value="65" <?php echo e(old('ddd', '85') == '65' ? 'selected' : ''); ?>>65</option>
                                 <option value="66" <?php echo e(old('ddd', '85') == '66' ? 'selected' : ''); ?>>66</option>
                                 <option value="67" <?php echo e(old('ddd', '85') == '67' ? 'selected' : ''); ?>>67</option>
                                 <option value="27" <?php echo e(old('ddd', '85') == '27' ? 'selected' : ''); ?>>27</option>
                                 <option value="28" <?php echo e(old('ddd', '85') == '28' ? 'selected' : ''); ?>>28</option>
                                 <option value="31" <?php echo e(old('ddd', '85') == '31' ? 'selected' : ''); ?>>31</option>
                                 <option value="32" <?php echo e(old('ddd', '85') == '32' ? 'selected' : ''); ?>>32</option>
                                 <option value="33" <?php echo e(old('ddd', '85') == '33' ? 'selected' : ''); ?>>33</option>
                                 <option value="34" <?php echo e(old('ddd', '85') == '34' ? 'selected' : ''); ?>>34</option>
                                 <option value="35" <?php echo e(old('ddd', '85') == '35' ? 'selected' : ''); ?>>35</option>
                                 <option value="37" <?php echo e(old('ddd', '85') == '37' ? 'selected' : ''); ?>>37</option>
                                 <option value="38" <?php echo e(old('ddd', '85') == '38' ? 'selected' : ''); ?>>38</option>
                                 <option value="21" <?php echo e(old('ddd', '85') == '21' ? 'selected' : ''); ?>>21</option>
                                 <option value="22" <?php echo e(old('ddd', '85') == '22' ? 'selected' : ''); ?>>22</option>
                                 <option value="24" <?php echo e(old('ddd', '85') == '24' ? 'selected' : ''); ?>>24</option>
                                 <option value="11" <?php echo e(old('ddd', '85') == '11' ? 'selected' : ''); ?>>11</option>
                                 <option value="12" <?php echo e(old('ddd', '85') == '12' ? 'selected' : ''); ?>>12</option>
                                 <option value="13" <?php echo e(old('ddd', '85') == '13' ? 'selected' : ''); ?>>13</option>
                                 <option value="14" <?php echo e(old('ddd', '85') == '14' ? 'selected' : ''); ?>>14</option>
                                 <option value="15" <?php echo e(old('ddd', '85') == '15' ? 'selected' : ''); ?>>15</option>
                                 <option value="16" <?php echo e(old('ddd', '85') == '16' ? 'selected' : ''); ?>>16</option>
                                 <option value="17" <?php echo e(old('ddd', '85') == '17' ? 'selected' : ''); ?>>17</option>
                                 <option value="18" <?php echo e(old('ddd', '85') == '18' ? 'selected' : ''); ?>>18</option>
                                 <option value="19" <?php echo e(old('ddd', '85') == '19' ? 'selected' : ''); ?>>19</option>
                                 <option value="41" <?php echo e(old('ddd', '85') == '41' ? 'selected' : ''); ?>>41</option>
                                 <option value="42" <?php echo e(old('ddd', '85') == '42' ? 'selected' : ''); ?>>42</option>
                                 <option value="43" <?php echo e(old('ddd', '85') == '43' ? 'selected' : ''); ?>>43</option>
                                 <option value="44" <?php echo e(old('ddd', '85') == '44' ? 'selected' : ''); ?>>44</option>
                                 <option value="45" <?php echo e(old('ddd', '85') == '45' ? 'selected' : ''); ?>>45</option>
                                 <option value="46" <?php echo e(old('ddd', '85') == '46' ? 'selected' : ''); ?>>46</option>
                                 <option value="51" <?php echo e(old('ddd', '85') == '51' ? 'selected' : ''); ?>>51</option>
                                 <option value="53" <?php echo e(old('ddd', '85') == '53' ? 'selected' : ''); ?>>53</option>
                                 <option value="54" <?php echo e(old('ddd', '85') == '54' ? 'selected' : ''); ?>>54</option>
                                 <option value="55" <?php echo e(old('ddd', '85') == '55' ? 'selected' : ''); ?>>55</option>
                                 <option value="47" <?php echo e(old('ddd', '85') == '47' ? 'selected' : ''); ?>>47</option>
                                 <option value="48" <?php echo e(old('ddd', '85') == '48' ? 'selected' : ''); ?>>48</option>
                                 <option value="49" <?php echo e(old('ddd', '85') == '49' ? 'selected' : ''); ?>>49</option>
                              </select>
                               <input style="padding: 10px;" name="number" id="number" value="<?php echo e(old('number')); ?>" required placeholder="9 9999-9999">
                           </div>
                        </div>
                        <div class="form-group">
                           <label for="birthdate">Data de nascimento</label>
                           <div class="associate">
                              <input style="padding: 10px;" name="birthdate" id="birthdate" value="<?php echo e(old('birthdate')); ?>" required placeholder="dd/mm/aaaa">
                           </div>
                              <?php if($errors->has('birthdate')): ?>
                                 <div class="invalid-feedback" style="color: #ff0000">
                                       <?php echo e($errors->first('birthdate')); ?>

                                 </div>
                              <?php endif; ?>
                        </div>
                        <?php if($eventID): ?>
                        <input type="hidden" name="eventID" id="eventID" value="<?php echo e($eventID); ?>">
                        <?php endif; ?>
                        <input type="hidden" name="phonenumber" id="phonenumber" value="<?php echo e(old('phonenumber')); ?>">
                        <div class="CTA" style="display: flex;">
                           <input type="submit" value="Entrar">
                           <a href="https://wa.me/5585991634968?text=Ol%C3%A1.%20Estou%20com%20d%C3%BAvidas%20no%20site%20listinha%20vip%20">Precisa de ajuda?</a>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </section>
      <?php endif; ?>
   </div>
</body>
</html>

<script>
   $(document).ready(function () {

      $('input#code').on('input', function() {
         $(this).mask('000');
         let code = $(this).val();
         let ddd = $('select#ddd').val();
         let number = $('input#number').val().replace(/[^\d]/g, '');
         $('#phonenumber').val(code+ddd+number);
      });

      $('select#ddd').change(function() {
         let code = $('input#code').val().replace(/[^\d]/g, '');
         let ddd = $(this).val();
         let number = $('input#number').val().replace(/[^\d]/g, '');
         $('#phonenumber').val(code+ddd+number);
      });

      $('input#number').on('input', function() {
         $(this).mask('0 0000-0000');
         let code = $('input#code').val().replace(/[^\d]/g, '');
         let ddd = $('select#ddd').val();
         let number = $(this).val().replace(/[^\d]/g, '');
         $('#phonenumber').val(code+ddd+number);
      });

   $('input#birthdate').on('input', function () {
      $(this).mask('00/00/0000')
   });

});
</script><?php /**PATH C:\laragon\www\event-management\resources\views/public/customer-form.blade.php ENDPATH**/ ?>