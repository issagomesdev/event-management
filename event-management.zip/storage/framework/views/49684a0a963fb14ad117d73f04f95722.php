<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.customer.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.customers.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.customer.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="surname"><?php echo e(trans('cruds.customer.fields.surname')); ?></label>
                <input class="form-control <?php echo e($errors->has('surname') ? 'is-invalid' : ''); ?>" type="text" name="surname" id="surname" value="<?php echo e(old('surname', '')); ?>" required>
                <?php if($errors->has('surname')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('surname')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.surname_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="phonenumber"><?php echo e(trans('cruds.customer.fields.phonenumber')); ?></label>
                <input class="form-control <?php echo e($errors->has('phonenumber') ? 'is-invalid' : ''); ?>" type="text" name="phonenumber" id="phonenumber" value="<?php echo e(old('phonenumber', '')); ?>" required>
                <?php if($errors->has('phonenumber')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('phonenumber')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.phonenumber_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.customer.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="birthdate"><?php echo e(trans('cruds.customer.fields.birthdate')); ?></label>
                <input class="form-control date <?php echo e($errors->has('birthdate') ? 'is-invalid' : ''); ?>" type="text" name="birthdate" id="birthdate" value="<?php echo e(old('birthdate')); ?>" required>
                <?php if($errors->has('birthdate')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('birthdate')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.customer.fields.birthdate_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\event-management\resources\views/admin/customers/create.blade.php ENDPATH**/ ?>